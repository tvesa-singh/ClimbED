
import Link from 'next/link';

export default function Navbar() {
  const navLinks = [
    { href: '/', text: 'Mission' },
    { href: '/statistics', text: 'Statistics' },
    { href: '/exploration', text: 'Career Exploration' },
    { href: '/internships', text: 'Internships' },
    { href: '/articles', text: 'Articles' },
    { href: '/about', text: 'About Us' }
  ];

  return (
    <nav className="bg-white shadow-md py-4 px-6 flex justify-between items-center sticky top-0 z-50">
      <span className="text-xl font-bold text-indigo-600">ClimbED</span>
      <ul className="flex space-x-6">
        {navLinks.map((link) => (
          <li key={link.href}>
            <Link href={link.href} className="hover:text-indigo-500 font-medium">
              {link.text}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
}
