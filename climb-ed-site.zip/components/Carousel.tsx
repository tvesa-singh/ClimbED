
import Image from 'next/image';
import { useState } from 'react';

export const Carousel = ({ images }) => {
  const [index, setIndex] = useState(0);
  return (
    <div className="relative w-full max-w-xl mx-auto">
      <Image src={images[index]} alt="slide" width={600} height={400} className="rounded-lg" />
      <div className="flex justify-between mt-4">
        <button onClick={() => setIndex((i) => (i - 1 + images.length) % images.length)}>Prev</button>
        <button onClick={() => setIndex((i) => (i + 1) % images.length)}>Next</button>
      </div>
    </div>
  );
};
