import { motion } from 'framer-motion';

export default function Statistics() {
  return (
    <motion.div initial={{ x: -100, opacity: 0 }} animate={{ x: 0, opacity: 1 }}>
      <h1 className="text-4xl font-bold mb-6">Statistics</h1>
      <ul className="list-disc ml-6 space-y-4">
        <li>
          According to the U.S. Department of Education, students from low-income backgrounds are five times more likely to drop out of high school than their higher-income peers. (NCES)
        </li>
        <li>
          In 2022, only 14% of low-income students completed a bachelor’s degree within eight years of high school graduation. (NCES, 2022)
        </li>
        <li>
          Students with access to career exploration programs are 20% more likely to pursue postsecondary education. (ACTE)
        </li>
      </ul>
    </motion.div>
  );
}