export default function Internships() {
  return (
    <div>
      <h1 className="text-4xl font-bold mb-6">Internship Submissions</h1>
      <form name="internship" method="POST" data-netlify="true" className="space-y-4">
        <input type="hidden" name="form-name" value="internship" />
        <input name="name" placeholder="Full Name" required className="input" />
        <input name="email" type="email" placeholder="Email" required className="input" />
        <input name="phone" type="tel" placeholder="Phone Number" required className="input" />
        <textarea name="resume" placeholder="Paste your resume here..." required className="input"></textarea>
        <textarea name="paragraphs" placeholder="Interest and goals (2 paragraphs)" required className="input"></textarea>
        <button type="submit" className="btn">Submit</button>
      </form>
    </div>
  );
}