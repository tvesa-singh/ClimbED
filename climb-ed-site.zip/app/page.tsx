import Image from 'next/image';
import { motion } from 'framer-motion';

export default function Mission() {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <h1 className="text-4xl font-bold mb-6">Our Mission</h1>
      <p className="text-lg max-w-2xl mb-6">
        ClimbED is an initiative led by high school girls from Central Jersey committed to bridging the education gap, providing accessible resources, and inspiring youth to explore their future career paths. We believe that education should be empowering, equitable, and exciting.
      </p>
      <Image src="/images/education.jpg" alt="Education themed image" width={600} height={400} className="rounded-xl shadow-lg" />
    </motion.div>
  );
}