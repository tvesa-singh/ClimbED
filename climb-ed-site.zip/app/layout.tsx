
import './globals.css';
import Navbar from '../components/Navbar';

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="font-sans bg-gradient-to-br from-sky-100 to-indigo-200 text-gray-800">
        <Navbar />
        <main className="px-4 md:px-16 py-8">{children}</main>
      </body>
    </html>
  );
}
