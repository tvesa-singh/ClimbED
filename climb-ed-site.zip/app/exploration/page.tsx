import { Carousel } from '../../components/Carousel';

export default function CareerExploration() {
  return (
    <div>
      <h1 className="text-4xl font-bold mb-6">Career Exploration</h1>
      <Carousel images={['/slides/1.png', '/slides/2.png', '/slides/3.png']} />
    </div>
  );
}