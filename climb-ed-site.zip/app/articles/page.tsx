export default function Articles() {
  return (
    <div>
      <h1 className="text-4xl font-bold mb-6">Submit an Article</h1>
      <form name="articles" method="POST" data-netlify="true" className="space-y-4">
        <input type="hidden" name="form-name" value="articles" />
        <input name="title" placeholder="Article Title" required className="input" />
        <textarea name="content" placeholder="Write your article here..." rows={8} className="input"></textarea>
        <button type="submit" className="btn">Submit</button>
      </form>
    </div>
  );
}