export default function AboutUs() {
  return (
    <div>
      <h1 className="text-4xl font-bold mb-6">About Us</h1>
      <p className="text-lg mb-4">
        We are a group of girls from Central Jersey passionate about education equity and career readiness. Our goal is to make education resources more accessible and inspiring for students of all backgrounds.
      </p>
      <div className="w-full max-w-md">
        <input type="file" className="file-input" />
      </div>
    </div>
  );
}